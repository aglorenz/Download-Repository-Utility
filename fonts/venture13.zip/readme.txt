You can download and use however you want.  No stipulations.  No credit necessary. 

https://www.behance.net/swillings